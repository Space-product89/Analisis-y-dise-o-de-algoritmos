def factorial():
    numero = int(input('Ingrese un número para calcular su factorial: '))
    resultado = calcular_factorial(numero)
    print(f'El factorial de {numero} es {resultado}')

def calcular_factorial(numero):
    if numero <= 1:
        return 1
    return numero * calcular_factorial(numero - 1)

factorial()
