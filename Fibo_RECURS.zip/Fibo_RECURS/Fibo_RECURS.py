def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)

def encontrar_posicion(numero, n=0):
    if numero == fibonacci(n):
        return n
    if numero < fibonacci(n):
        return -1
    return encontrar_posicion(numero, n + 1)

numero = int(input("Ingrese un número para encontrar en la serie de Fibonacci: "))
posicion = encontrar_posicion(numero)

if posicion != -1:
    print(f"El número {numero} se encuentra en la posición {posicion} de la serie de Fibonacci.")
else:
    print(f"El número {numero} no está en la serie de Fibonacci.")
