def ordenamiento_burbuja(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]

def ordenamiento_burbuja_optimizado(arr):
    n = len(arr)
    intercambiado = False
    for i in range(n):
        intercambiado = False
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]
                intercambiado = True
        if not intercambiado:
            break

def main():
    print("Seleccione el método de ordenamiento:")
    print("1. Burbuja")
    print("2. Burbuja Optimizada")
    
    opcion = int(input("Ingrese su elección (1/2): "))
    
    if opcion == 1:
        n = int(input("Ingrese el tamaño de la lista: "))
        lista = []
        for i in range(n):
            elemento = int(input(f"Ingrese el elemento {i + 1}: "))
            lista.append(elemento)
        
        ordenamiento_burbuja(lista)
        print("Lista ordenada con el método de Burbuja:")
        print(lista)
        
    elif opcion == 2:
        n = int(input("Ingrese el tamaño de la lista: "))
        lista = []
        for i in range(n):
            elemento = int(input(f"Ingrese el elemento {i + 1}: "))
            lista.append(elemento)
        
        ordenamiento_burbuja_optimizado(lista)
        print("Lista ordenada con el método de Burbuja Optimizada:")
        print(lista)
        
    else:
        print("Opción no válida. Por favor, seleccione 1 o 2.")

if __name__ == "__main__":
    main()
