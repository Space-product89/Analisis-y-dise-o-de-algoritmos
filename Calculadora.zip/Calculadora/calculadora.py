import time
import os

print('\t\tCalculadora')
print('**************************************************')

while True:
    print('****¿Que deseas hacer?****')
    print('1. Sumar')
    print('2. Restar')
    print('3. Multiplicar')
    print('4. Dividir')
    print('5. Salir')
    print('**********************')
    opc= input('ingrese una opcion: ')
    print('\n')
    
    inicio = time.time()
    if opc == "1":
        print('ingrese Numero 1:')
        n1 = float(input())
        print('ingrese Numero 2:')
        n2 = float(input())
        
        S=n1+n2
        print('El resultado de la suma es de: ', S)
        print('\n')
        
    elif opc == "2":
        print('ingrese Numero 1:')
        n1 = float(input())
        print('ingrese Numero 2:')
        n2 = float(input())
        
        R=n1-n2
        print('El resultado de la resta es de: ', R)
        print('\n')
        
    elif opc == "3":
        print('ingrese Numero 1:')
        n1 = float(input())
        print('ingrese Numero 2:')
        n2 = float(input())
        
        M=n1*n2
        print('El producto es de: ', M)
        print('\n')
    
    elif opc == "4":
        print('ingrese Numero 1:')
        n1 = float(input())
        print('ingrese Numero 2:')
        n2 = float(input())

        D=n1/n2
        print('El resultado de la division es de: ', D)
        print('\n')
    
    elif opc == '5':
        print('***** Hasta luego! :D *****')
        time.sleep(1.5)
        break
    
    else:
        print('Aun no existe esa función, intenta de nuevo :(')   
        print('\n\n')
        
    fin = time.time()
    tiempo_ejecutado = fin - inicio
    print('Tiempo de operacion', tiempo_ejecutado)  
    print('\n\n') 
    os.system("pause")
    os.system("cls")