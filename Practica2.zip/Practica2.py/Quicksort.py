# Importar las bibliotecas necesarias
import random  # Para generar números aleatorios
import time    # Para medir el tiempo de ejecución
import matplotlib.pyplot as plt  # Para graficar los tiempos de ordenamiento

# Función de partición para QuickSort
def Divide(array, left, right):
    pivot = array[left]
    while True:
        # Recorre la lista izquierda
        while array[left] < pivot:
            left += 1
            if left >= right:
                break

        # Recorre la lista derecha
        while array[right] > pivot:
            right -= 1
            if left >= right:
                break

        if left >= right:
            # Indica un punto de reinicio
            return right
        else:
            # Realiza intercambios
            array[left], array[right] = array[right], array[left]
            # Continúa avanzando
            left += 1
            right -= 1

# Función de QuickSort
def quicksort(array, left, right):
    if left < right:
        DivideIndex = Divide(array, left, right)
        quicksort(array, left, DivideIndex)
        quicksort(array, DivideIndex + 1, right)

# Genera un arreglo aleatorio
def generate_array():
    n = random.randint(5, 1000)  # Tamaño del arreglo
    a = 0  # Valor mínimo
    b = 100  # Valor máximo

    arr = [random.randint(a, b) for _ in range(n)]
    return arr

# Almacena los tiempos de ordenamiento
sorting_times = []

# Almacena los arreglos ordenados
sorted_arrays = []

# Itera y ordena los arreglos
for i in range(100):
    arr = generate_array()
    original_arr = arr.copy()  # Realiza una copia del arreglo original
    start = time.time()
    quicksort(arr, 0, len(arr) - 1)
    end = time.time()
    tiempo_ejecutado = end - start
    sorting_times.append(tiempo_ejecutado)
    sorted_arrays.append(arr)

    print("Arreglo Original:", original_arr)  # Imprime el arreglo original
    print("Arreglo Ordenado:", arr)
    print('Tiempo de ejecución:', tiempo_ejecutado)

# Grafica los tiempos de ordenamiento
plt.plot(sorting_times)
plt.xlabel("Número de arreglo")
plt.ylabel("Tiempo de ordenamiento (segundos)")
plt.show()

# Obtiene los índices de los tres arreglos que más tiempo tomaron y los tres que menos tiempo tomaron
top_3_slowest = sorted(range(len(sorting_times)), key=lambda i: sorting_times[i], reverse=True)[:3]
top_3_fastest = sorted(range(len(sorting_times)), key=lambda i: sorting_times[i])[:3]

# Muestra los tres arreglos que más tiempo tomaron en ordenarse
for i in top_3_slowest:
    print("Arreglo que más tiempo tomó en ordenar:", sorted_arrays[i])

# Muestra los tres arreglos que menos tiempo tomaron en ordenarse
for i in top_3_fastest:
    print("Arreglo que menos tiempo tomó en ordenar:", sorted_arrays[i])
  

"""
# Prueba...
array = [7, 6, 7, 3, 6, 3, 25, 6, 4, 32, 55, 7, 65, 4, 32]
print("Original: ")
print(array)
quicksort(array, 0, len(array) - 1)
print("Ordenado: ")
print(array)
"""