#Algortimo de dijkstra

import graphlib
import time
import random
import matplotlib.pyplot as plt
import networkx as nx

#Generar grafos

